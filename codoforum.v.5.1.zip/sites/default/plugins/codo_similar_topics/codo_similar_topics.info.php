<?php

$info['name'] = 'Similar Topics';
$info['plugin_type']= 'block';
$info['description'] = 'Lists similar topics';
$info['version'] = '1.x';
$info['author'] = "Codologic";
$info['author_url'] = 'http://codologic.com';
$info['license'] = 'GNU GPL V3';
$info['core'] = '2.x';
