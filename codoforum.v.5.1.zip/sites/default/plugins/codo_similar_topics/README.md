# codo_similar_topics
list similar topics for codoforum forum software http://codoforum.com

![related forum topics](http://i60.tinypic.com/3469wti.jpg)


###How to install:
- Download/clone this plugin(repository).
- rename the folder to `codo_similar_topics`
- move the folder to `sites/default/plugins` directory
- Go to the backend and enable the plugin.
- In the backend, go to UI Elements -> Blocks.
- Add a new Block.

![add block settings](http://i62.tinypic.com/n181g1.jpg)

- Set Block Region as: `block_topic_info_after`
- Set Block Output as: `Plugin`
- Set plugin as: `codo_similar_topics`
- Save the block then click on any topic to view related topics :)

----
- For any Help visit the forums: http://codologic.com/forum
- Twitter: https://twitter.com/codologic
