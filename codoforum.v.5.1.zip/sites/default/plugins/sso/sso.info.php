<?php

$info['name'] = 'Single Sign On';
$info['description'] = 'SSO with auto-login';
$info['version'] = '2.x';
$info['author'] = "Adesh D'Silva";
$info['author_url'] = 'http://codologic.com';
$info['license'] = 'GNU GPL V3';
$info['core'] = '1.x';
