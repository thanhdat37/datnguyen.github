<?php

$info['name'] = 'AntiSpamRules';
$info['description'] = 'Provides option to set standard anti-spam rules';
$info['version'] = '2.x';
$info['author'] = "Codologic";
$info['author_url'] = 'https://codoforum.com';
$info['license'] = 'GNU GPL V3';
$info['core'] = '4.x';
