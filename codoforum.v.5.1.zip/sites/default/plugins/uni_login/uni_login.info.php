<?php

$info['name'] = 'Uni Login';
$info['description'] = 'Provides option to sign in with Google/FB/Twitter etc';
$info['version'] = '2.x';
$info['author'] = "Adesh D'Silva";
$info['author_url'] = 'https://codoforum.com';
$info['license'] = 'GNU GPL V3';
$info['core'] = '1.x';
